## REST API = how to services/platforms communicate. uses standard protocols such as http or https for more security.
## why REST APIs = Idempotency (no matter how many calls the same data returns - consistent data) and statelessness (no client saves data, in request needs the full information needed to execute request (more perfomant and scalable))

'''
search for books - GET optional - title

borrow a book - PUT param: title, user id

return a book - PUT param: title

view which books they have borrowed - GET param: user id

ASSUMPTION: there is no multiple of 1 book so only one.
ASSUMPTION: each book title is unique
'''

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from objects.libraryService import Library

app = FastAPI()

#non-persistent storage
library = Library()

@app.get('/books')
def getbooks():
    return {title: {"borrower_id": book.borrower_id} for title, book in library.books.items()}

@app.get('/books/{title}')
def getbook(title: str):
    try:
        book = library.search_book(title)
        return {"title": book.title, "borrower_id": book.borrower_id}
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))

@app.put('/books/borrow/{title}/{userid}')
def borrowbook(title: str, userid: int):
    try:
        library.borrow_book(title,userid)
        return {"status": "borrowed", "title": title, "user_id": userid}
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.put('/books/return/{title}')
def returnbook(title: str):
    try:
        library.return_book(title)
        return {"status": "returned", "title": title}
    except ValueError as e:
        raise HTTPException(STATUS_CODE=400, detail=str(e))

@app.get('/yourbooks/{userid}')
def getyourbooks(userid: int):
    books = library.view_your_books(userid)
    return [{"title": b.title} for b in books]

@app.post('/addbook/{title}')
def addbook(title: str):
    library.add_book(title)
    return {"Success": f"Book {title} has been added to the inventory"}

## Ways to extend in real world - 
## Security - Rate limiting for Ddos and fair use, CORS, HTTPS, Auth tokens 
## Scalability - use cloud services for easy horizontal scaling -> deploy docker images for easy setup using K8s
## Versioning - for changing api while keeping backwards compatibility

## For more real world user, have a users model for user details and have multiple books per 1 title
#  When a user takes out a book reduce quantity by 1
#  Have a end date for returns
#  Have a post for creating new book entries
#  Have a delete for removing books that have not been retruned
#  Use persistent storage like a SQL Database 