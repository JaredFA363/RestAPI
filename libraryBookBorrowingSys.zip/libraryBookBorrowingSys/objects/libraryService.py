'''
- Class Library
 - init books

 - functions
   search for books -> search and return

   borrow a book -> set borrow_id to user_id

   return a book -> set borrow_id to 0

   view which books they have borrowed -> search and return

'''
from .bookobj import Book

class Library():
    def __init__(self):
        # library is a collection of books
        self.books = {}

    def add_book(self, title: str):
        if title in self.books:
            raise ValueError("Book already exists")
        self.books[title] = Book(title)
            

    def borrow_book(self, title: str, userId: int):
        if title not in self.books:
            raise ValueError("Book not found")
        book = self.books[title]
        if book.borrower_id != 0:
            raise ValueError("Book already borrowed")
        book.borrower_id = userId

    def search_book(self, title: str = None):
        if not title:
            return list(self.books.values())
        if title not in self.books:
            raise ValueError("Book not found")
        return self.books[title]

    def return_book(self, title):
        if title not in self.books:
            raise ValueError("Book not found")
        book = self.books[title]
        book.borrower_id = 0

    def view_your_books(self, userId):
        return [b for b in self.books.values() if b.borrower_id == userId]