'''
 - Class: book
    - init: title (unique), borrower_id = [0 (noone), userId(someone) ] will default to 0
'''

class Book():
    def __init__(self, title: str, borrower_id: int = 0):
        self.title = title
        self.borrower_id = borrower_id