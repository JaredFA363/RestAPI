from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from objects.libraryService import Library

app = FastAPI()

# ----------------------------------------------------
# In-memory service instance
# (Say this: “In a real system this would be a DB.”)
# ----------------------------------------------------
library = Library()


# ----------------------------------------------------
# Pydantic Models (Very important for validation)
# Say this: “These ensure all inputs are validated.” 
# ----------------------------------------------------
class BorrowRequest(BaseModel):
    title: str
    user_id: int

class ReturnRequest(BaseModel):
    title: str

class AddBookRequest(BaseModel):
    title: str


# ----------------------------------------------------
# GET all books
# Say this: "This allows querying all book states."
# ----------------------------------------------------
@app.get("/books")
def get_books():
    return [
        {"title": b.title, "borrower_id": b.borrower_id}
        for b in library.get_all_books()
    ]


# ----------------------------------------------------
# GET a specific book
# Say this: "This returns only one book or 404."
# ----------------------------------------------------
@app.get("/books/{title}")
def get_book(title: str):
    try:
        book = library.search_book(title)
        return {"title": book.title, "borrower_id": book.borrower_id}
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))


# ----------------------------------------------------
# POST Add a book
# Say this: "POST creates new resources."
# ----------------------------------------------------
@app.post("/books")
def add_book(request: AddBookRequest):
    try:
        library.add_book(request.title)
        return {"message": f"Book '{request.title}' added"}
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


# ----------------------------------------------------
# PUT Borrow a book
# Say this: "PUT is a safe choice for idempotent state updates."
# ----------------------------------------------------
@app.put("/books/borrow")
def borrow_book(request: BorrowRequest):
    try:
        library.borrow_book(request.title, request.user_id)
        return {"message": f"{request.title} borrowed by user {request.user_id}"}
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


# ----------------------------------------------------
# PUT Return a book
# Say this: "Returning a book is idempotent and safe for PUT."
# ----------------------------------------------------
@app.put("/books/return")
def return_book(request: ReturnRequest):
    try:
        library.return_book(request.title)
        return {"message": f"{request.title} returned"}
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


# ----------------------------------------------------
# GET books a user has borrowed
# Say this: "A filtered GET by user_id."
# ----------------------------------------------------
@app.get("/users/{user_id}/books")
def get_user_books(user_id: int):
    books = library.view_your_books(user_id)
    return [{"title": b.title} for b in books]
