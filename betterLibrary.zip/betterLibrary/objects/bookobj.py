class Book:
    # Say this: “Simple data class holding book state.”
    def __init__(self, title: str, borrower_id: int = 0):
        self.title = title
        self.borrower_id = borrower_id
