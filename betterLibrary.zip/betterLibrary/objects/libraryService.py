from .bookobj import Book

class Library:
    def __init__(self):
        # Say this: “Dictionary gives O(1) lookups by title.”
        self.books = {}

    def add_book(self, title: str):
        if title in self.books:
            raise ValueError("Book already exists")
        self.books[title] = Book(title)

    def get_all_books(self):
        return list(self.books.values())

    def search_book(self, title: str):
        if title not in self.books:
            raise ValueError("Book not found")
        return self.books[title]

    def borrow_book(self, title: str, user_id: int):
        if title not in self.books:
            raise ValueError("Book not found")

        book = self.books[title]

        if book.borrower_id != 0:
            raise ValueError("Book already borrowed")

        book.borrower_id = user_id

    def return_book(self, title: str):
        if title not in self.books:
            raise ValueError("Book not found")

        # Say this: "Return is idempotent: calling twice yields same state."
        self.books[title].borrower_id = 0

    def view_your_books(self, user_id: int):
        return [b for b in self.books.values() if b.borrower_id == user_id]
