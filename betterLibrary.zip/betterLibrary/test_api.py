from fastapi.testclient import TestClient
from api import app

client = TestClient(app)

# Helper for nice printing during demo (optional)
def show(resp):
    print("STATUS:", resp.status_code)
    print("BODY:", resp.json())
    print("-" * 40)


# ------------------------------------------------------
# 1. Test adding books
# ------------------------------------------------------
def test_add_books():
    resp = client.post("/books", json={"title": "Harry Potter"})
    assert resp.status_code == 200
    assert resp.json()["message"] == "Book 'Harry Potter' added"

    resp = client.post("/books", json={"title": "Lord of the Rings"})
    assert resp.status_code == 200

    # Duplicate add should fail
    resp = client.post("/books", json={"title": "Harry Potter"})
    assert resp.status_code == 400
    assert "exists" in resp.json()["detail"].lower()


# ------------------------------------------------------
# 2. Test getting all books
# ------------------------------------------------------
def test_get_all_books():
    resp = client.get("/books")
    assert resp.status_code == 200
    body = resp.json()
    assert isinstance(body, list)
    assert len(body) >= 2  # depending on previous tests


# ------------------------------------------------------
# 3. Borrow a book
# ------------------------------------------------------
def test_borrow_book():
    resp = client.put("/books/borrow", json={"title": "Harry Potter", "user_id": 1})
    assert resp.status_code == 200
    assert "borrowed" in resp.json()["message"].lower()

    # Borrow again by another user → should fail
    resp = client.put("/books/borrow", json={"title": "Harry Potter", "user_id": 2})
    assert resp.status_code == 400
    assert "already borrowed" in resp.json()["detail"].lower()


# ------------------------------------------------------
# 4. Get one book
# ------------------------------------------------------
def test_get_specific_book():
    resp = client.get("/books/Harry Potter")
    assert resp.status_code == 200
    assert resp.json()["borrower_id"] == 1


# ------------------------------------------------------
# 5. User borrowed books
# ------------------------------------------------------
def test_user_books():
    resp = client.get("/users/1/books")
    assert resp.status_code == 200
    titles = [b["title"] for b in resp.json()]
    assert "Harry Potter" in titles


# ------------------------------------------------------
# 6. Returning a book
# ------------------------------------------------------
def test_return_book():
    resp = client.put("/books/return", json={"title": "Harry Potter"})
    assert resp.status_code == 200

    # Returning again → still success (idempotent)
    resp = client.put("/books/return", json={"title": "Harry Potter"})
    assert resp.status_code == 200

    # Now the user should have no books
    resp = client.get("/users/1/books")
    assert resp.status_code == 200
    assert resp.json() == []
