import requests

BASE = "http://127.0.0.1:8000"

# -------------------------------
# Helper to pretty-print responses
# -------------------------------
def show(response):
    print(f"STATUS: {response.status_code}")
    try:
        print("BODY:", response.json())
    except:
        print("BODY (raw):", response.text)
    print("-" * 50)  # separator line


# -------------------------------
# 1. Add some books
# -------------------------------
print("Adding books...")
resp = requests.post(f"{BASE}/books", json={"title": "Harry Potter"})
show(resp)

resp = requests.post(f"{BASE}/books", json={"title": "Lord of the Rings"})
show(resp)

# Duplicate test
resp = requests.post(f"{BASE}/books", json={"title": "Harry Potter"})
show(resp)


# -------------------------------
# 2. View all books
# -------------------------------
print("Getting all books...")
resp = requests.get(f"{BASE}/books")
show(resp)


# -------------------------------
# 3. Borrow a book
# -------------------------------
print("Borrowing Harry Potter for user 1...")
resp = requests.put(f"{BASE}/books/borrow", json={"title": "Harry Potter", "user_id": 1})
show(resp)

# Borrow the same book again (should error)
resp = requests.put(f"{BASE}/books/borrow", json={"title": "Harry Potter", "user_id": 2})
show(resp)


# -------------------------------
# 4. Check a specific book
# -------------------------------
print("Checking book Harry Potter...")
resp = requests.get(f"{BASE}/books/Harry Potter")
show(resp)


# -------------------------------
# 5. Get books borrowed by a user
# -------------------------------
print("Get books borrowed by user 1...")
resp = requests.get(f"{BASE}/users/1/books")
show(resp)


# -------------------------------
# 6. Return a book
# -------------------------------
print("Returning Harry Potter...")
resp = requests.put(f"{BASE}/books/return", json={"title": "Harry Potter"})
show(resp)

# Return again (idempotent)
resp = requests.put(f"{BASE}/books/return", json={"title": "Harry Potter"})
show(resp)


# -------------------------------
# 7. Get all books again
# -------------------------------
print("Getting all books after return...")
resp = requests.get(f"{BASE}/books")
show(resp)
