import requests

BASE = "http://127.0.0.1:8000"

requests.post(f'{BASE}/tasks/add', json={'desc': 'Buy groceries'})
requests.post(f'{BASE}/tasks/add', json={'desc': 'Read a book'})
print(requests.get(f'{BASE}/tasks').json())