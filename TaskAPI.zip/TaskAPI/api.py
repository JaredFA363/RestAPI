'''
REST API services and platforms to communicate, it uses standard http protocols.

PROS: statelesness, idempotency

create a task - Post - param: task desc

delete a task - DELETE - param : task id

mark task as done - Put - param task id

get all tasks - Get

get only completed tasks - Get - param: completed=true

'''

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from objects.taskmanager import TaskManager

app = FastAPI()

class TaskRequest(BaseModel):
    desc: str

# In-memory task manager instance
task_manager = TaskManager()

@app.get('/tasks')
def get_all_task():
    return [{"id": t.id, "desc": t.desc, "completed": t.completed} for t in task_manager.view_all_tasks()]

@app.post('/tasks/add')
def create_task(request: TaskRequest):
    task = task_manager.add_task(request.desc)
    return {"id": task.id, "desc": task.desc, "completed": task.completed}

@app.delete('/tasks/{task_id}')
def delete_task(task_id: int):
    try:
        task_manager.remove_task(task_id)
        return {"status": "deleted", "task_id": task_id}
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    
@app.put('/tasks/{task_id}/complete')
def complete_task(task_id: int):
    try:
        task_manager.mark_task_as_completed(task_id)
        return {"status": "completed", "task_id": task_id}
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    
@app.get('/tasks/completed')
def get_completed_tasks():
    return [{"id": t.id, "desc": t.desc, "completed": t.completed} for t in task_manager.view_completed_tasks()]