'''
class Task:
    init: id, desc, completed

'''

class Task:
    def __init__(self, id: int, desc: str, completed: bool = False):
        self.id = id
        self.desc = desc
        self.completed = completed
