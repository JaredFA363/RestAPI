'''
class TaskManager:
init: list of tasks

functions:
    add task -> add to list
    
    remove task -> remove from list
    
    mark task as completed -> set completed to True
    
    view all tasks -> return list of tasks

    view completed tasks -> filter and return completed tasks

'''

from .task import Task

class TaskManager():
    def __init__(self):
        # List to store tasks
        self.tasks = []
        self.next_id = 1  # To assign unique IDs to tasks

    def add_task(self, desc: str):
        task = Task(id=self.next_id, desc=desc)
        self.tasks.append(task)
        self.next_id += 1
        return task

    def remove_task(self, task_id: int):
        for i, task in enumerate(self.tasks):
            if task.id == task_id:
                del self.tasks[i]
                return
        raise ValueError("Task not found")

    def mark_task_as_completed(self, task_id: int):
        for task in self.tasks:
            if task.id == task_id:
                task.completed = True
                return
        raise ValueError("Task not found")

    def view_all_tasks(self):
        return self.tasks

    def view_completed_tasks(self):
        return [task for task in self.tasks if task.completed]
    